package com.ust.jobseeker.exceptions;

public class PersonNotExistsException extends Exception{

}
