package com.ust.jobseeker.service;

import java.util.List;

import com.ust.jobseeker.model.Profile;

public interface ProfileService {

	void createProfile(Profile profile);

	void getProfileById(int profileId);

	void deleteProfileById(int profileId);

	void deketeAllProfile();

	void updateProfile(Profile profile);

	List<Profile> getAllProfiless();

	void getProfileDetailsByNameAndEmail(String fullName, String email);

	void getProfileByName(String fullName);

	void getByEmail(String email);

}
