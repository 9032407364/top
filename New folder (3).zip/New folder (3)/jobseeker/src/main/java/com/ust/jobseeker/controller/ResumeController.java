package com.ust.jobseeker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.netflix.discovery.converters.Auto;
import com.ust.jobseeker.exceptions.PersonNotExistsException;
import com.ust.jobseeker.model.Jobseeker;
import com.ust.jobseeker.model.Profile;
import com.ust.jobseeker.model.Resume;
import com.ust.jobseeker.service.ResumeService;

@RestController
@RequestMapping("/api/v1/")
public class ResumeController {
     
	@Autowired
	private ResumeService resumeService;
	
	private ResponseEntity responseEntity;
	
	 @PostMapping("resume")
		ResponseEntity<Jobseeker> addResume(@RequestBody Resume resume) throws PersonNotExistsException 
		{
			System.out.println(resume);
			resumeService.createResume(resume);
			return new ResponseEntity("NEW RESUME CREATED",HttpStatus.CREATED);		
		}
		
	 @GetMapping("getResumeById/{resumeId}")
	    public ResponseEntity<Resume> getResumeDetails(@PathVariable  int resumeId)   {
		 try {
			 resumeService.getResumeById(resumeId);
	        	responseEntity = new ResponseEntity(resumeId , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 
	 @GetMapping("getAllresumes")
		public ResponseEntity<List<Resume>> getAllResums() {
		 List<Resume> jobs = resumeService.getAllResums();
		return new ResponseEntity<List<Resume>>(jobs, HttpStatus.OK);

		}
	 
	 @RequestMapping(value = "updateResume", method = RequestMethod.PUT)
	// @PutMapping("/api/v1/update")
		public ResponseEntity<Resume> updateData(@RequestBody Resume resume){
			
			resumeService.updateResume(resume);
			ResponseEntity<Resume> ep=new ResponseEntity<Resume>(HttpStatus.CREATED);
			
			return ep;	
		}
	 
	 //@RequestMapping(value = "/delete/{resumeId}", method = RequestMethod.DELETE)
	 @DeleteMapping("deleteResume/{resumeId}")
		public ResponseEntity<Resume> EmployeeDelete(@PathVariable Integer resumeId){
			resumeService.deleteResumeById(resumeId);
			return new ResponseEntity<Resume>(HttpStatus.OK);
			 
		}
	 
	 @DeleteMapping("deleteAllResume")
		public ResponseEntity<Resume> deketeAllResums(){
		 resumeService.deketeAllResums();
		return new ResponseEntity<Resume>( HttpStatus.OK);

		}
	 
	 @GetMapping("getByResumeName/{fullName}")
	    public ResponseEntity<Profile> getProfileDetailsByName(@PathVariable  String fullName)   {
		 try {
			 resumeService.getProfileByName(fullName);
	        	responseEntity = new ResponseEntity(fullName , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 @GetMapping("getByResumeEmail/{email} ")
	    public ResponseEntity<Profile> getByEmail(@PathVariable  String email)   {
		 try {
			 resumeService.getByEmail(email);
	        	responseEntity = new ResponseEntity(email , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 
	
}
