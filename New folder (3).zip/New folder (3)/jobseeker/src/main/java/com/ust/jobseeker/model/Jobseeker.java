package com.ust.jobseeker.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Jobseeker {
	
	@Id
	@GeneratedValue
	int jobseekerId;
	
	String jobseekerName;
	 
	String jobseekerSkill;

	public int getJobseekerkId() {
		return jobseekerId;
	}

	public void setJobseekerId(int jobseekerId) {
		this.jobseekerId = jobseekerId;
	}

	public String getJobseekerName() {
		return jobseekerName;
	}

	public void setJobseekerName(String jobseekerName) {
		this.jobseekerName = jobseekerName;
	}

	public String getJobseekerSkill() {
		return jobseekerSkill;
	}

	public void setJobseekerSkill(String jobseekerSkill) {
		this.jobseekerSkill = jobseekerSkill;
	}

	@Override
	public String toString() {
		return "Jobseeker [jobseekerId=" + jobseekerId + ", jobseekerName=" + jobseekerName + ", jobseekerSkill="
				+ jobseekerSkill + "]";
	}
		
	
}
