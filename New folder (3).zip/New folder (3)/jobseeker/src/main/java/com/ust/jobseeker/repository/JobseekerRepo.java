package com.ust.jobseeker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
 
import org.springframework.stereotype.Repository;

import com.ust.jobseeker.model.Jobseeker;

@Repository
public interface JobseekerRepo extends JpaRepository<Jobseeker, Integer>  {

	Jobseeker getOne(int newsId);

	boolean existsByJobseekerName(String jobseekerName);

	//boolean existsByFirstName(String jobseekerName);

}
