package com.ust.jobseeker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.jobseeker.model.Profile;

@Repository
public interface ProfileRepositry extends JpaRepository<Profile, Integer>{
 
	void findByFullName(String fullName);

	 

	void findByFullNameAndEmail(String fullName, String email);



	void findByEmail(String email);

}
