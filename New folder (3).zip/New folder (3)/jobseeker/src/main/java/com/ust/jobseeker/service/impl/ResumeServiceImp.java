package com.ust.jobseeker.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import com.ust.jobseeker.model.Resume;
import com.ust.jobseeker.repository.ResumeRepositry;
import com.ust.jobseeker.service.ResumeService;

@Service
public class ResumeServiceImp implements ResumeService{
	
	@Autowired
	private ResumeRepositry resumeRepositry;

	@Override
	public void createResume(Resume resume) {
		resumeRepositry.save(resume);
		
	}

	@Override
	public Optional<Resume> getResumeById(int resumeId) {
		Optional<Resume> resume=resumeRepositry.findById(resumeId);
		return resume;
	}

	@Override
	public void updateResume(Resume resume) {
		resumeRepositry.save(resume);
		
	}

	@Override
	public void deleteResumeById(Integer resumeId) {
		resumeRepositry.deleteById(resumeId);
		
	}


	@Override
	public List<Resume> getAllResums() {
		List<Resume> list=resumeRepositry.findAll();
		return list;
	}

	@Override
	public void deketeAllResums() {
		resumeRepositry.deleteAll( );
		
	}

	@Override
	public void getProfileByName(String fullName) {
		resumeRepositry.findByFullName(fullName);
		
	}

	@Override
	public void getByEmail(String email) {
		resumeRepositry.findByEmail(email);
		
	}

}
