package com.ust.jobseeker.service;

import java.util.List;

import com.ust.jobseeker.exceptions.PersonNotExistsException;
import com.ust.jobseeker.model.Jobseeker;
import com.ust.jobseeker.model.Resume;

public interface JobseekerService {
	
	 
    Jobseeker addJobseeker(Jobseeker jobseeker) throws PersonNotExistsException;
	Jobseeker updateJobs(Jobseeker jobseeker, int jobseekerId) throws PersonNotExistsException ;
	void deleteById(int jobseekerId) throws PersonNotExistsException;
	List<Jobseeker> getAllJobs();
	//Jobseeker getJobById(int jobseekerId) throws PersonNotExistsException;
	void getJobseekerDetails(int jobseekerId);
	boolean existMethod(String jobseekerName);
	 
}
