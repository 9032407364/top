package com.ust.jobseeker.service;

import java.util.List;
import java.util.Optional;

import com.ust.jobseeker.model.Resume;

public interface ResumeService {

	void createResume(Resume resume);

	Optional<Resume> getResumeById(int resumeId);

	void updateResume(Resume resume);

	void deleteResumeById(Integer resumeId);

	List<Resume> getAllResums();

	void deketeAllResums();

	void getProfileByName(String fullName);

	void getByEmail(String email);

}
