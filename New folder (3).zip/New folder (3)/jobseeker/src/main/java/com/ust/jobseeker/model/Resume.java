package com.ust.jobseeker.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Resume {

	@Id
	@GeneratedValue
	int resumeId;
	
	private String fullName;
	
	private String email;
	
	private String mobileNo;
	
	private String skillSet;
	
	private String location;
	
	private String higherEducation;
	
	private String jobSeekerDescription;
	
	private String jobSeekerExp;

	int jobId;

	public int getResumeId() {
		return resumeId;
	}

	public void setResumeId(int resumeId) {
		this.resumeId = resumeId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail () {
		return email;
	}

	public void setEmailId(String email) {
		this.email = email ;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getHigherEducation() {
		return higherEducation;
	}

	public void setHigherEducation(String higherEducation) {
		this.higherEducation = higherEducation;
	}

	public String getJobSeekerDescription() {
		return jobSeekerDescription;
	}

	public void setJobSeekerDescription(String jobSeekerDescription) {
		this.jobSeekerDescription = jobSeekerDescription;
	}

	public String getJobSeekerExp() {
		return jobSeekerExp;
	}

	public void setJobSeekerExp(String jobSeekerExp) {
		this.jobSeekerExp = jobSeekerExp;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	
	@Override
	public String toString() {
		return "Resume [resumeId=" + resumeId + ", fullName=" + fullName + ", email=" + email 
				+ ", mobileNo=" + mobileNo + ", skillSet=" + skillSet + ", location=" + location + ", higherEducation="
				+ higherEducation + ", jobSeekerDescription=" + jobSeekerDescription + ", jobSeekerExp=" + jobSeekerExp
				+ ", jobId=" + jobId + "]";
	}

	 
	 
	
	
}
