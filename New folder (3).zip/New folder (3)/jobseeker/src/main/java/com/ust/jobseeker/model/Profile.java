package com.ust.jobseeker.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Profile {

	@Id
	@GeneratedValue
	private int profileId;
	private String fullName;
	private String email;
	private String password;
	private String conformPassword;
	private long   mobileNo;
	private String primarySkill;
	private String experience;
	private String status;
	
	
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmailId(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConformPassword() {
		return conformPassword;
	}
	public void setConformPassword(String conformPassword) {
		this.conformPassword = conformPassword;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPrimarySkill() {
		return primarySkill;
	}
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	
	
	@Override
	public String toString() {
		return "Profile [profileId=" + profileId + ", fullName=" + fullName + ", email=" + email + ", password="
				+ password + ", conformPassword=" + conformPassword + ", mobileNo=" + mobileNo + ", primarySkill="
				+ primarySkill + ", experience=" + experience + "]";
	}
	
	
	
}
