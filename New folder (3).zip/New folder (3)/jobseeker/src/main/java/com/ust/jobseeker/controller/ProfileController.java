package com.ust.jobseeker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.jobseeker.exceptions.PersonNotExistsException;
import com.ust.jobseeker.model.Jobseeker;
import com.ust.jobseeker.model.Profile;
import com.ust.jobseeker.model.Resume;
import com.ust.jobseeker.service.ProfileService;

@RestController
@RequestMapping("/api/v1/")
public class ProfileController {

	@Autowired
	private ProfileService profileSrvice;
	
	private ResponseEntity responseEntity;
	 
	 @PostMapping("profile")
		ResponseEntity<Profile> addProfile(@RequestBody Profile profile) throws PersonNotExistsException 
		{
			System.out.println(profile);
			profileSrvice.createProfile(profile);
			return new ResponseEntity(profile,HttpStatus.CREATED);		
		}
		
	 @GetMapping("getById/{profileId}")
	    public ResponseEntity<Profile> getProfileDetails(@PathVariable  int profileId)   {
		 try {
			 profileSrvice.getProfileById(profileId);
	        	responseEntity = new ResponseEntity(profileId , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 
	 @GetMapping("profile")
		public ResponseEntity<List<Profile>> getAllProfiless() {
		 List<Profile> profile = profileSrvice.getAllProfiless();
		return new ResponseEntity<List<Profile>>(profile, HttpStatus.OK);

		}
	 
	 @RequestMapping(value = "updateProfile", method = RequestMethod.PUT)
	// @PutMapping("/api/v1/update")
		public ResponseEntity<Profile> updateProfileData(@RequestBody Profile profile){
			
		 profileSrvice.updateProfile(profile);
			ResponseEntity<Profile> ep=new ResponseEntity<Profile>(HttpStatus.CREATED);
			
			return ep;	
		}
	 
	 //@RequestMapping(value = "/delete/{resumeId}", method = RequestMethod.DELETE)
	 @DeleteMapping("deleteById/{profileId}")
		public ResponseEntity<Resume> ProfileDelete(@PathVariable int profileId){
		 profileSrvice.deleteProfileById(profileId);
			return new ResponseEntity<Resume>(HttpStatus.OK);
			 
		}
	 
	 @DeleteMapping("deleteProfile")
		public ResponseEntity<Profile> deketeAllProfile(){
		 profileSrvice.deketeAllProfile();
		return new ResponseEntity<Profile>( HttpStatus.OK);

		}
	
	 @GetMapping("getByNameAndEmail")
	    public ResponseEntity<Profile> getProfileDetailsByNameAndEmail(@PathVariable  String fullName,@PathVariable String email)   {
		 try {
			 profileSrvice.getProfileDetailsByNameAndEmail(fullName,email);
	        	responseEntity = new ResponseEntity( HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 @GetMapping("getByName/{fullName}")
	    public ResponseEntity<Profile> getProfileDetailsByName(@PathVariable  String fullName)   {
		 try {
			 profileSrvice.getProfileByName(fullName);
	        	responseEntity = new ResponseEntity(fullName , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 @GetMapping("getByEmail/{email} ")
	    public ResponseEntity<Profile> getByEmail(@PathVariable  String email)   {
		 try {
			 profileSrvice.getByEmail(email);
	        	responseEntity = new ResponseEntity(email , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 
}
