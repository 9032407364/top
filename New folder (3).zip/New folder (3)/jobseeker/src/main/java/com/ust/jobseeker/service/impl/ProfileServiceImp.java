package com.ust.jobseeker.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.jobseeker.model.Profile;
import com.ust.jobseeker.repository.ProfileRepositry;
import com.ust.jobseeker.service.ProfileService;

@Service
public class ProfileServiceImp implements ProfileService{

	@Autowired
	private ProfileRepositry profileRepositry;
	
	@Override
	public void createProfile(Profile profile) {
		 
		profileRepositry.save(profile);
	}

	@Override
	public void getProfileById(int profileId) {
		profileRepositry.findById(profileId);
		
	}

	@Override
	public void deleteProfileById(int profileId) {
		profileRepositry.deleteById(profileId);
		
	}

	@Override
	public void deketeAllProfile() {
		profileRepositry.deleteAll();
		
	}

	@Override
	public void updateProfile(Profile profile) {
		profileRepositry.save(profile);
		
	}

	@Override
	public List<Profile> getAllProfiless() {
		List<Profile> list=profileRepositry.findAll();
		return list;
	}

	@Override
	public void getProfileDetailsByNameAndEmail(String fullName, String email) {
		profileRepositry.findByFullNameAndEmail(fullName,email);
		
	}

	@Override
	public void getProfileByName(String fullName) {
		profileRepositry.findByFullName(fullName);
		
	}

	@Override
	public void getByEmail(String email) {
		profileRepositry.findByEmail(email);
		
	}

}
