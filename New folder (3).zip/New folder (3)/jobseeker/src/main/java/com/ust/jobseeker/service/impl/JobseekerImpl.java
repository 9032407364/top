package com.ust.jobseeker.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.jobseeker.exceptions.PersonNotExistsException;
import com.ust.jobseeker.model.Jobseeker;
import com.ust.jobseeker.model.Resume;
import com.ust.jobseeker.repository.JobseekerRepo;
import com.ust.jobseeker.service.JobseekerService;

@Service
public class JobseekerImpl implements JobseekerService{

	@Autowired
	JobseekerRepo jsRepo;

	@Override
	public Jobseeker addJobseeker(Jobseeker jobseeker) throws PersonNotExistsException {
		if (jsRepo.existsById(jobseeker.getJobseekerkId())) {
			throw new PersonNotExistsException();
			
		}
		else {
			return jsRepo.save(jobseeker);
		}

		
	}

	@Override
	public Jobseeker updateJobs(Jobseeker jobseeker, int jobseekerId) throws PersonNotExistsException {
		if (jsRepo.existsById(jobseekerId)) {
			Jobseeker jobs = new Jobseeker();
			 
			jobseeker.setJobseekerId(jobseeker.getJobseekerkId());
			jobseeker.setJobseekerName(jobseeker.getJobseekerName());
			jobseeker.setJobseekerSkill(jobseeker.getJobseekerSkill());

			return jsRepo.save(jobs);
		}

		else {
			throw new PersonNotExistsException();
		}

		
	}

	@Override
	public void deleteById(int jobseekerId) throws PersonNotExistsException {
		 
		jsRepo.deleteById(jobseekerId);
		
	}

	@Override
	public List<Jobseeker> getAllJobs() {
		return jsRepo.findAll();
	}

	/*
	 * Retrieve all existing news
	 */
	 

	@Override
	public void getJobseekerDetails(int jobseekerId) {
		jsRepo.findById(jobseekerId);
		
	}

	@Override
	public boolean existMethod(String jobseekerName) {
		boolean emplist=jsRepo.existsByJobseekerName(jobseekerName);
		return emplist;
	}

	 
	
	 

}
