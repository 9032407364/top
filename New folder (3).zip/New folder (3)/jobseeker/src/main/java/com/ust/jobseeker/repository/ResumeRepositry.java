package com.ust.jobseeker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.jobseeker.model.Resume;
@Repository
public interface ResumeRepositry extends JpaRepository<Resume, Integer> {

	void findByFullName(String fullName);

	void findByEmail(String email);

}
