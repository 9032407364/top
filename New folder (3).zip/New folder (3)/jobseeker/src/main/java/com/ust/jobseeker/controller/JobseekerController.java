package com.ust.jobseeker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.jobseeker.exceptions.PersonNotExistsException;
import com.ust.jobseeker.model.Jobseeker;
import com.ust.jobseeker.model.Resume;
import com.ust.jobseeker.service.JobseekerService;
import com.ust.jobseeker.service.ResumeService;

@RestController
@RequestMapping("api/v1/")
public class JobseekerController {

	
	@Autowired
	JobseekerService jsService;
	@Autowired
	ResumeService resumeService;
	
	private ResponseEntity responseEntity;
	
	@PostMapping("jobs")
	ResponseEntity<Jobseeker> addJobseeker(@RequestBody Jobseeker jobseeker) throws PersonNotExistsException 
	{
		System.out.println(jobseeker);
		jsService.addJobseeker(jobseeker);
		return new ResponseEntity(jobseeker,HttpStatus.CREATED);		
	}
	
	@GetMapping("get/{jobseekerId}")
    public ResponseEntity<?> getJobseekerDetails(@PathVariable  int jobseekerId)   {
	 try {
		 jsService.getJobseekerDetails(jobseekerId);
        	responseEntity = new ResponseEntity(jobseekerId , HttpStatus.OK);
        }
        catch (Exception e)
        {
            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }

		@GetMapping("jobs")
		//@ResponseBody
		public ResponseEntity<?> getAllJobs() {

			HttpHeaders headers = new HttpHeaders();
			
				List<Jobseeker> jobs = jsService.getAllJobs();
				return new ResponseEntity<List<Jobseeker>>(jobs, HttpStatus.OK);

		}
	
	@PutMapping("jobs/{jobseekerId}")
//	@ResponseBody
	public ResponseEntity<?> updateJobseeker(@RequestBody Jobseeker jobseeker,@PathVariable int jobseekerId) throws PersonNotExistsException {
		
			
		jsService.updateJobs(jobseeker,jobseekerId);
					return new ResponseEntity<Jobseeker>(jobseeker, HttpStatus.OK);

	}
	
	 @DeleteMapping("job/{jobseekerId}")
	    public ResponseEntity<?> deleteNews(@PathVariable("jobseekerId") int jobseekerId) throws PersonNotExistsException {

	        try {
	        	jsService.deleteById(jobseekerId);
	            responseEntity = new ResponseEntity("Successfully deleted !!!", HttpStatus.OK);
	        } catch (PersonNotExistsException e) {

	            throw new PersonNotExistsException();

	                    }
	        catch (Exception exception){
	            String ex = exception.getMessage();
	            System.out.println(exception.getMessage());
	            responseEntity = new ResponseEntity("Error !!! Try after sometime.", HttpStatus.NOT_FOUND);
	        }
	        return responseEntity;
	
	 }
	 
	 @RequestMapping(value = "Exist/{jobseekerName}", method = RequestMethod.GET)
	   public ResponseEntity <Boolean> existt(@RequestParam  String jobseekerName) throws PersonNotExistsException{
		  boolean listem=jsService.existMethod(jobseekerName);
		   if(listem==false) {
			   throw new PersonNotExistsException();
		   }
			return  new ResponseEntity <Boolean>(listem,HttpStatus.ACCEPTED);
	   }
	 
	 
	 /////################************RESUME************#####################################################
	 
	 
	 
}
