package com.ust.jobseeker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobseekerApplicationTests {

	@Test
	void contextLoads() {
	}

}
