package com.ust.administrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
