package com.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jwt.entity.User;
import com.jwt.service.UserService;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

   // @PostConstruct
    public void initRoleAndUser() {
        userService.initRoleAndUser();
    }
    @GetMapping("/allEmployers")
    public List<User> getAllemployers() {return userService.getallEmployers() ;}
    @GetMapping("/alljobseekers")
    public List<User> getAlljobseekers() {return userService.getallJobSeekers() ;}

    @PostMapping({"/registerNewUser"})
    public User registerNewUser(@RequestBody User user) {
        return userService.registerNewUser(user);
    }

    @GetMapping({"/forAdmin"})
    @PreAuthorize("hasRole('Admin')")
    public String forAdmin(){
        return "This URL is only accessible to the admin";
    }

    @GetMapping({"/forUser"})
    @PreAuthorize("hasRole('User')")
    public String forUser(){
        return "This URL is only accessible to the user";
    }
    @GetMapping({"/forEmployer"})
    @PreAuthorize("hasRole('Employer')")
    public String forEmployer(){
        return "This URL is only accessible to the Employer";
    }
}
