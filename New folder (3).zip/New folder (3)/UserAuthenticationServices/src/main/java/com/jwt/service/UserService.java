package com.jwt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jwt.dao.RoleDao;
import com.jwt.dao.UserDao;
import com.jwt.entity.Role;
import com.jwt.entity.User;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private RoleDao roleDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void initRoleAndUser() {

       
    }

    public User registerNewUser(User user) {
		/*
		 * Role role = roleDao.findById("User").get(); Set<Role> userRoles = new
		 * HashSet<>(); userRoles.add(role); user.setRole(userRoles);
		 * user.setUserPassword(getEncodedPassword(user.getUserPassword()));
		 */
    	Role adminRole = new Role();
        adminRole.setRoleName("Admin");
        adminRole.setRoleDescription("Admin role Created for the User");
        Set<Role> adminRol = new HashSet<>();
        adminRol.add(adminRole);
        
        Role userRole = new Role();
        userRole.setRoleName("User");
        userRole.setRoleDescription("JobSeeker role Created for the User");
        Set<Role> userrol = new HashSet<>();
        userrol.add(userRole);
        
        Role employerRole = new Role();
        employerRole.setRoleName("Employer");
        employerRole.setRoleDescription("Employer role Created for the User");
        Set<Role> emprol = new HashSet<>();
        emprol.add(employerRole);
        
    	 Set<Role> Roless = new HashSet<>();
    	 User users =new User();
    	 users=(User)user;
    	 
    	 if(users.getRoles().matches("Admin")) {
    		 
    		users.setRole(adminRol);
        Roless.addAll(users.getRole());
        roleDao.saveAll(Roless);
        }
    	 else if (users.getRoles().matches("User")) {
    		 
     		users.setRole(userrol);
    	        Roless.addAll(user.getRole());
    	        roleDao.saveAll(Roless);
    	        }
    	 else if (users.getRoles().matches("Employer")) {
    		
     		users.setRole(emprol);
    	        Roless.addAll(user.getRole());
    	        roleDao.saveAll(Roless);
    	        }
        System.out.println(users.toString());
		/*
		 * users.setAddress(user.getAddress());
		 * users.setCompanyName(user.getCompanyName());
		 * users.setExperience(user.getExperience());
		 * users.setPrimarySkill(user.getPrimarySkill());
		 * users.setRecruiterName(user.getRecruiterName()); users.(user.getAddress());
		 */
    	if (user.getUserName().isEmpty()) {
       return null;}
    	else {users.setActive(true);
    		users.setUserPassword(getEncodedPassword(user.getUserPassword()));
        return userDao.save(users);}
    }
    
    public List<User> getallEmployers() {
    	User user=new User() ;
    	List<User> list=new ArrayList() ;
    	Optional<User>users=null;
		/*
		 * Iterable<User> userss=userDao.findAll(); Iterator<User> a=userss.iterator();
		 * while(a.hasNext()) {List<User> users=null;
		 * if(a.next().getRoles()=="Employer") {users=(List<User>) a.next();}
		 * 
		 * }
		 * 
		 * return users;
		 */
    	Iterable<User> a=userDao.findAll();
    	Iterator<User> b=a.iterator();
    while(b.hasNext()) {user= b.next();
    if(user.getRoles().equalsIgnoreCase("Employer")) {
    	users=userDao.findById(user.getUserName());
    	list.add(users.get());
    }
    
    }
    
    	
    	return list;}
    
    
    public List<User> getallJobSeekers() {
    	User user=new User() ;
    	List<User> list=new ArrayList() ;
    	Optional<User>users=null;
		/*
		 * Iterable<User> userss=userDao.findAll(); Iterator<User> a=userss.iterator();
		 * while(a.hasNext()) {List<User> users=null;
		 * if(a.next().getRoles()=="Employer") {users=(List<User>) a.next();}
		 * 
		 * }
		 * 
		 * return users;
		 */
    	Iterable<User> a=userDao.findAll();
    	Iterator<User> b=a.iterator();
    while(b.hasNext()) {user= b.next();
    if(user.getRoles().equalsIgnoreCase("User")) {
    	users=userDao.findById(user.getUserName());
    	list.add(users.get());
    }
    
    }
    
    	
    	return list;}
    
    

    public String getEncodedPassword(String password) {
        return passwordEncoder.encode(password);
    }
    
    
}

