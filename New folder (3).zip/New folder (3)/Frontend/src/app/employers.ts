export class Employers {
    userName!: string
    userEmail!: string
      userMobileNumber!: string
      companyName!: string
      address!: string
}
