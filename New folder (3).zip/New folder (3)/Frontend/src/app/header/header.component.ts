import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employer } from '../models/employer';
import { EmployerService } from '../_services/employer.service';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  constructor(private employer:EmployerService,
    private userAuthService: UserAuthService,
    private router: Router,
    public userService: UserService
  ) {}
  model!:Employer[]
  ngOnInit(): void {this.get}
getdata!:boolean
username!:string
  public isLoggedIn() {
  this.username = this.userAuthService.getUser()
    return this.userAuthService.isLoggedIn();

  }

  data(){this.getdata=true}
  get(){this.employer.getemployerList(). subscribe(data=>{this.model=data})}
  public logout() {this.username=''
    this.userAuthService.clear();
    this.router.navigate(['/home']);
  }

}
