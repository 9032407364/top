import { Component, OnInit } from '@angular/core';
import { Employers } from '../employers';
import { Employer } from '../models/employer';
import { EmployerService } from '../_services/employer.service';
import { JobseekerService } from '../_services/jobseeker.service';

@Component({
  selector: 'app-emp-dashboard',
  templateUrl: './emp-dashboard.component.html',
  styleUrls: ['./emp-dashboard.component.css']
})
export class EmpDashboardComponent implements OnInit {
model!:Employer[]
mod!:Employer
get:boolean=true
delete!:boolean
update!:boolean
create!:boolean
id!:number
  constructor(private employer:EmployerService) { }

  ngOnInit(): void {
    this.getdetails()
  }
Get(){this.getdetails()
  this.get=true
  this.delete=false
  this.update=false
  this.create=false}
Delete(){this.getdetails()
  this.delete=true
  this.update=false
  this.create=false
  this.get=false
}
Update(){this.getdetails()
  this.update=true
  this.delete=false
  this.get=false
  this.create=false}
Create(){this.getdetails()
  this.create=true
  this.delete=false
  this.update=false
  this.get=false}
  getdetails(){this.employer.getemployerList(). subscribe(data=>{this.model=data})}
  updatedetails(){this.Get();this.employer.updateemployer(this.id,this.mod). subscribe(data=>{this.getdetails()})}
  deletedetails(id:string){this.Get();this.employer.delete(id). subscribe(data=>{})}
  createdetails(emp:Employer){this.employer.createemployer(emp). subscribe(data=>{this.getdetails()})}
  getdetailsByid(id:number){this.employer.getemployerById(id). subscribe(data=>{this.mod=data})}
}
