import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employer } from 'src/app/models/employer';
import { EmployerService } from 'src/app/_services/employer.service';

@Component({
  selector: 'app-getdata',
  templateUrl: './getdata.component.html',
  styleUrls: ['./getdata.component.css']
})
export class GetdataComponent implements OnInit {
  model!:Employer[]
  mod!:Employer
  login!:String
  apply!:String


    constructor(private employer:EmployerService, private router: Router) { }
  
    ngOnInit(): void {
      this.getdetails()
    }
    applyjob(){this.apply='Please login and apply job'}
    getdetails(){this.employer.getemployerList(). subscribe(data=>{this.model=data})}

}
