import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { EmpDashboardComponent } from './emp-dashboard/emp-dashboard.component';
import { GetdataComponent } from './emp-dashboard/getdata/getdata.component';

//import { EmployerRegComponent } from './employer-reg/employer-reg.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { HomeComponent } from './home/home.component';

import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { AppliedjobsComponent } from './user/appliedjobs/appliedjobs.component';
import { EditprofileComponent } from './user/editprofile/editprofile.component';
import { UserComponent } from './user/user.component';
import { ViewprofileComponent } from './user/viewprofile/viewprofile.component';
import { AuthGuard } from './_auth/auth.guard';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'admin', component: AdminComponent, canActivate:[AuthGuard], data:{roles:['Admin']} },
  { path: 'user', component: UserComponent ,  canActivate:[AuthGuard], data:{roles:['User']} },
  { path: 'login', component: LoginComponent },
  { path: 'forbidden', component: ForbiddenComponent },
  { path: 'reg', component: RegistrationComponent },
 // { path: 'empreg', component: EmployerRegComponent },
  { path: 'empdash', component: EmpDashboardComponent },
  
  { path: 'viewprofile', component: ViewprofileComponent },
  { path: 'editprofile', component: EditprofileComponent },
  { path: 'appliedjobs', component: AppliedjobsComponent },
  { path: 'getdata', component: GetdataComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
