import { Component, OnInit } from '@angular/core';
import { Jobseeker } from '../models/jobseeker';
import { JobseekerService } from '../_services/jobseeker.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  
  
  jobs:any = { 
    companyName:"Ust Global", 
    jobTitle:"Python" ,
    jobLocation:"Hyderabad",
    dateofapply:"2022-10-13", 
    status:"Active" 


 }; 



name:any='Profile Details'
  message: any;
viewprofile!:boolean
gsearch!:string
model!:Jobseeker[]
mod!:Jobseeker
  constructor(private userService: UserService,private jobseeker:JobseekerService) { }

  ngOnInit(): void {
    this.forUser();
  }

  getall!:boolean
  get!:boolean
  delete!:boolean
  update!:boolean
  create!:boolean
  id!:number
  Getall(){this.getall=true
    this.get=false
    this.delete=false
    this.update=false
    this.create=false}
  Get(){this.get=false
    this.delete=false
    this.update=false
    this.create=false
    this.getall=true}
  Delete(){this.getall=false
    this.delete=true
    this.update=false
    this.create=false
    this.get=false
  }
  Update(){this.update=true
    this.delete=false
    this.get=false
    this.create=false
    this.getall=false}
  Create(){this.create=true
    this.delete=false
    this.update=false
    this.get=false
    this.getall=false}
  Viewprofile(){this.viewprofile=true

  }

  getdetails(){this.jobseeker.getJobseekerList(). subscribe(data=>{this.model=data})}
  updatedetails(id:number,emp:Jobseeker){this.jobseeker.updateJobseeker(id,emp). subscribe(data=>{this.getdetails()})}
  deletedetails(id:number){this.jobseeker.deleteJobseeker(id). subscribe(data=>{this.getdetails()})}
  createdetails(emp:Jobseeker){this.jobseeker.createJobseeker(emp). subscribe(data=>{this.getdetails()})}
  getdetailsByid(id:number){this.jobseeker.getJobseekerById(id). subscribe(data=>{this.mod=data})}




  forUser() {
    this.userService.forUser().subscribe(
      (response) => {
        console.log(response);
        this.message = response;
      }, 
      (error)=>{
        console.log(error);
      }
    );
  }
}
