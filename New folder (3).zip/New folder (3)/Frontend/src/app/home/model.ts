export  class Model{
    
to!:any
    ADA!:any 
    AED!: any
    AFN!: any


}