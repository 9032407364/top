import { Component, OnInit } from '@angular/core';
import { JobseekerService } from '../_services/jobseeker.service';
import { Model } from './model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
message!:boolean
  constructor(private a:JobseekerService) { }
model!:Model
  ngOnInit(): void {this.getdata()
  }
get(){this.message=true}
getdata(){this.a.getJobseeker().subscribe(data=>{this.model=data})}}
