import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AuthGuard } from './_auth/auth.guard';
import { AuthInterceptor } from './_auth/auth.interceptor';
import { UserService } from './_services/user.service';

//import { EmployerRegComponent } from './employer-reg/employer-reg.component';
import { EmpDashboardComponent } from './emp-dashboard/emp-dashboard.component';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { RegistrationComponent } from './registration/registration.component';
import { ViewprofileComponent } from './user/viewprofile/viewprofile.component';
import { EditprofileComponent } from './user/editprofile/editprofile.component';
import { AppliedjobsComponent } from './user/appliedjobs/appliedjobs.component';
import { GetdataComponent } from './emp-dashboard/getdata/getdata.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminComponent,
    UserComponent,
    LoginComponent,
    HeaderComponent,
    ForbiddenComponent,
   RegistrationComponent,
   // EmployerRegComponent,
    EmpDashboardComponent,
    RegistrationComponent,
    ViewprofileComponent,
    EditprofileComponent,
    AppliedjobsComponent,
   
    GetdataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    FormsModule,
     ReactiveFormsModule,
     RxReactiveFormsModule 
     
  ],
  providers: [
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass:AuthInterceptor,
      multi:true
    },
    UserService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
