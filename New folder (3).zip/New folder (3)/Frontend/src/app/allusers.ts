export class Users {
    userName: string='vemuri'
   userEmail!: string
     userMobileNumber!: string
    primarySkill!: string
    experience!: string

}