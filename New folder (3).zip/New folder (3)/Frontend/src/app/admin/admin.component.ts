import { Component, OnInit } from '@angular/core';
import { Users } from '../allusers';
import { Employers } from '../employers';
import { AdminService } from '../_services/admin.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
usr!:Users[];
emps!:Employers[];
  constructor(private adminservice:AdminService) { }
  mainpage: boolean = true
  allusers!: boolean
  allemployers!: boolean
  ngOnInit(): void {
  }
  users() {
    this.allusers = true
    this.mainpage = false
    this.getallusers()
  }
  Mainpage(){this.allusers =false 
    this.mainpage = true
    this.allemployers = false}
  employers() {
    this.allemployers = true
    this.getallEmployers();
    this.allusers = false
    this.mainpage = false
  }
  employerActive(id:string){
    this.adminservice.getadminById(id).subscribe( data => {
      console.log(data);
      
    })
   
  }
  getallEmployers(){this.adminservice.getemployersList().subscribe(data=>{this.emps=data})}

  getallusers(){this.adminservice.getjobseekerList().subscribe(data=>{this.usr=data})}
  employerinActive(id:string){}
  userActive(id:string){this.adminservice.deleteadmin(id).subscribe(data=>{ })}
  userinActive(id:string){}
}
