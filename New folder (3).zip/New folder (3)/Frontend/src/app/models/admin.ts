export class Admin{
    // id!: number;
    // firstName!: string;
    // lastName!: string;
    // emailId!: string;
    roleName:string="Admin"
    roleDescription:string="Default role for newly created record"
}