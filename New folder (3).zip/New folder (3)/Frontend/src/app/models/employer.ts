export class Employer {
    companyName!: string;
    recruiterName!: string;
    locaton!: string;
    mobileNumber!: number;
    emailId!: string;
    mebmerShip!: string;
    status!: string;
    action!: string;
    JobId!: number;
    jobTitle!: string;
    category!: string;
    jobLocation!: string;
    jobDescription!: string;
    jobExperience!: string;
    publishedAt!: string;
    resumeId!: number;
    jobSeekerName!: string;
    jobSeekerDescription!: string;
    jobSeekerExp!: string;
    ijobId!: number;
}