export class Jobseeker {
    jobseekerName!: string;
    jobseekerSkill!: string;
    profileId!: number;
    fullName!: string;
    email!: string;
    password!: string;
    conformPassword!: string;
    mobileNo!: number;
    primarySkill!: string;
    experience!: string;
    status!: string;
   resumeId!: number;
    skillSet!: string;
    location!: string;
    higherEducation!: string;
    jobSeekerDescription!: string;
    jobSeekerExp!: string;
   jobId!: number;
}