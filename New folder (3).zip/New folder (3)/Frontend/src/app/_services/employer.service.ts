import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employer } from '../models/employer';

@Injectable({
  providedIn: 'root'
})
export class EmployerService {

  private baseURL = "http://localhost:9000/api/v1";

  constructor(private httpClient: HttpClient) { }
  
  getemployerList(): Observable<Employer[]>{
    return this.httpClient.get<Employer[]>(`${this.baseURL}`+'/getAllJobs');
  }

  createemployer(employer: Employer): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, employer);
  }

  getemployerById(id: number): Observable<Employer>{
    return this.httpClient.get<Employer>(`${this.baseURL}/${id}`);
  }

  updateemployer(id: number, employer: Employer): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, employer);
  }

  delete(id: String): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}+'/deleteByJobId'/${id}`);
  }
}
