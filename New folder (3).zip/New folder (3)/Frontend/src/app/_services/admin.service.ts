import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from '../allusers';
import { Employers } from '../employers';
import { Admin } from '../models/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

private baseURL = "http://localhost:9090/allEmployers";
private baseurl = "http://localhost:9090/alljobseekers";

  constructor(private httpClient: HttpClient) { }
  
  getemployersList(): Observable<Employers[]>{
    return this.httpClient.get<Employers[]>(`${this.baseURL}`);
  }
  getjobseekerList(): Observable<Users[]>{
    return this.httpClient.get<Users[]>(`${this.baseurl}`);
  }
  createadmin(admin: Admin): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, admin);
  }

  getadminById(id: String): Observable<Employers>{
    return this.httpClient.get<Employers>(`${this.baseURL}/${id}`);
  }

  updateadmin(id: number, admin: Admin): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, admin);
  }

  deleteadmin(id: string): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
