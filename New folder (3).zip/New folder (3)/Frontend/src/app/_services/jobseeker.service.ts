import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Model } from '../home/model';
import { Jobseeker } from '../models/jobseeker';

@Injectable({
  providedIn: 'root'
})
export class JobseekerService {

  private baseURL = "https://firebase.googleapis.com/v1alpha/projects/-/apps/1:820819117977:web:eabf3544ac136b1a643508/webConfig";
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });
  constructor(private httpClient: HttpClient) { }
  
  getJobseekerList(): Observable<Jobseeker[]>{
    return this.httpClient.get<Jobseeker[]>(`${this.baseURL}`);
  }

  createJobseeker(jobseeker: any): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`+'/registerNewUser', jobseeker,{headers:this.requestHeader});
  }

  getJobseekerById(id: number): Observable<Jobseeker>{
    return this.httpClient.get<Jobseeker>(`${this.baseURL}/${id}`);
  }
  getJobseeker(): Observable<Model>{
    return this.httpClient.get<Model>(`${this.baseURL}`);
  }
  updateJobseeker(id: number, jobseeker: Jobseeker): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, jobseeker);
  }

  deleteJobseeker(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
