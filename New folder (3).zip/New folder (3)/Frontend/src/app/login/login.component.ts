import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(
    private userService: UserService,
    private userAuthService: UserAuthService,
    private router: Router
  ) { }
message!:string
  ngOnInit(): void { }

  login(loginForm: NgForm) {
    this.userService.login(loginForm.value).subscribe(
      (response: any) => {
        this.message=''     
        this.  userAuthService.setUser(response.user.userName)               
        this.userAuthService.setRoles(response.user.role);
        this.userAuthService.setToken(response.jwtToken);
        for (let i = 0; i < response.user.role.length; i++) {
          const role = response.user.role[i].roleName;
          console.log ("Block statement execution no." + i);
        
        
        if (role === 'Admin') {
          this.router.navigate(['/admin']);
        } else if (role === 'Employer') { this.router.navigate(['/empdash']); }
        else if(role==='User') {
          this.router.navigate(['/user']);
        }}
      },
      (error) => {
        console.log(error);
        this.message='please check the details'
      }
    );
  }
}
