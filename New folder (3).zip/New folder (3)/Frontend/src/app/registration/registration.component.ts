import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  adminregistration: boolean = false
  empregistration: boolean = false
  jobseekerregistration: boolean = true

  message = '';
  
  registrationForm:FormGroup;
  empregistrationForm: FormGroup;
  jobregistrationForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private userService: UserService,
    private userAuthService: UserAuthService,
    private router: Router) {
      this.registrationForm = this.formBuilder.group({
        userName: ['', Validators.required],
        
       // userFirstName: ['', Validators.required],
       // userLastName: ['', Validators.required],
        userPassword: ['', Validators.required],
        //userMobileNumber: ['', Validators.required],
       // companyName: ['', Validators.required],
       // recruiterName: ['', Validators.required],
        roles: ['', Validators.required],
       // address: ['', Validators.required],
       // primarySkill: ['', Validators.required],
       // experience: ['', Validators.required],
        userEmail: ['', Validators.required]
        
      });

      this.jobregistrationForm = this.formBuilder.group({
        userName: ['', Validators.required],
        
        //userFirstName: ['', Validators.required],
        //userLastName: ['', Validators.required],
        userPassword: ['', Validators.required],
        userMobileNumber: ['', Validators.required],
       // companyName: ['', Validators.required],
       // recruiterName: ['', Validators.required],
        roles: ['', Validators.required],
       // address: ['', Validators.required],
        primarySkill: ['', Validators.required],
        experience: ['', Validators.required],
        userEmail: ['', Validators.required]
        
      }); this.empregistrationForm = this.formBuilder.group({
        userName: ['', Validators.required],
       
        //userFirstName: ['', Validators.required],
        //userLastName: ['', Validators.required],
        userPassword: ['', Validators.required],
        userMobileNumber: ['', Validators.required],
        companyName: ['', Validators.required],
        //recruiterName: ['', Validators.required],
        roles: ['', Validators.required],
        address: ['',Validators.required ],
       // primarySkill: ['', Validators.required],
       // experience: ['', Validators.required],
        userEmail: ['', Validators.required]
        
      });
    
    

   
  }
  adminreg() {
    this.empregistration = false
    this.jobseekerregistration = false
    this.adminregistration = true
    this.message=''
  }
  empreg() {
    this.empregistration = true
    this.jobseekerregistration = false
    this.adminregistration = false
    this.message=''
  }
  jobseekerreg() {
    this.empregistration = false
    this.jobseekerregistration = true
    this.adminregistration = false
    this.message=''
  }
  ngOnInit(): void {


  }
  
  
validateEmail(c: FormControl)
{
  let EMAIL_REGEXP = /^[\w._]+@[A-Za-z]+\.(com|co\.in|org)$/;
  return EMAIL_REGEXP.test(c.value) ? null : {
    emailError: { message: "Emailis Invalid" }
  };
}
register(registerForm: any) {
if((this.registrationForm.valid||this.jobregistrationForm.valid)||this.empregistrationForm.valid){
  this.userService.register(registerForm.value).subscribe(
    (response: any) => {

      this.message='Register Successfully'
      this.clearForm()
      //this.userAuthService.setRoles(response.user.role);
      //this.userAuthService.setToken(response.jwtToken);
      for (let i = 0; i < response.user.role.length; i++) {
        const role = response.user.role[i].roleName;
        console.log("Block statement execution no." + i);


        if (role === 'Admin') {
          this.router.navigate(['/login']);
        } else if (role === 'Employer') { this.router.navigate(['/login']); }
        else {
          this.router.navigate(['/login']);
        }
      }
    },
    (error) => {this.clearForm()
      this.message = 'Failed to Register!!'
      console.log(error);
    }
  );
}

else{this.clearForm()
  this.message = 'Please Check Valid Details'}
}

clearForm() {this.registrationForm.reset();
  this.jobregistrationForm.reset();this.empregistrationForm.reset();
}
}
