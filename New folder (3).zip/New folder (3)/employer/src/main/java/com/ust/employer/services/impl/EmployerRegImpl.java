package com.ust.employer.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.employer.dto.Employer;
import com.ust.employer.dto.Jobs;
import com.ust.employer.exceptions.EmployerNotFoundException;
import com.ust.employer.repository.EmployerRegRepo;
import com.ust.employer.services.EmployerRegService;

@Service
public class EmployerRegImpl implements EmployerRegService {

	@Autowired
	EmployerRegRepo erRepo;
	
	@Override
	public Employer addEmployer(Employer employer) {
		
		
		  Employer emp = new Employer(); 
		  emp.setCompanyId(employer.getCompanyId());
		  emp.setCompanyName(employer.getCompanyName());
		  emp.setEmailId(employer.getEmailId());
		  emp.setRecruiterName(employer.getRecruiterName());
		  emp.setMobileNumber(employer.getMobileNumber());
		  emp.setAction(employer.getAction());
		  emp.setLocaton(employer.getLocaton());
		  emp.setMebmerShip(employer.getMebmerShip());
		  emp.setStatus(employer.getStatus());
		erRepo.save(emp);
		
		return emp;
	}

	@Override
	public List<Employer> getAllEmployer() {
		List<Employer>employer=erRepo.findAll();
		return employer;
	}

	@Override
	public void deleteEmployerById(int companyId) {
		erRepo.deleteById(companyId);
		
	}

	@Override
	public boolean existMethod(String companyName) {
		boolean emplist=erRepo.existsByCompanyName(companyName);
		return emplist;
	}

	@Override
	public void getById(int companyId) throws EmployerNotFoundException {
		erRepo.findById(companyId);	
	}

	@Override
	public void deleteAllEmployer() {
		erRepo.deleteAll();
		
	}

	@Override
	public void getByCompanyName(String companyName) {
		erRepo.findByCompanyName(companyName);
		
	}

	@Override
	public void getByRecruiterName(String recruiterName) {
		erRepo.findByRecruiterName(recruiterName);
		
	}

	 

	
	
}
