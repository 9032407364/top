package com.ust.employer.exceptions;

public class JobIdNotFoundException extends Exception{

}
