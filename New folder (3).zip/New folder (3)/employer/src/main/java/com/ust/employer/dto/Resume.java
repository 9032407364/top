package com.ust.employer.dto;


public class Resume {

	int resumeId;
	
	String jobSeekerName;
	
	String jobSeekerDescription;
	
	String jobSeekerExp;

	int jobId;

	public int getResumeId() {
		return resumeId;
	}

	public void setResumeId(int resumeId) {
		this.resumeId = resumeId;
	}

	public String getJobSeekerName() {
		return jobSeekerName;
	}

	public void setJobSeekerName(String jobSeekerName) {
		this.jobSeekerName = jobSeekerName;
	}

	public String getJobSeekerDescription() {
		return jobSeekerDescription;
	}

	public void setJobSeekerDescription(String jobSeekerDescription) {
		this.jobSeekerDescription = jobSeekerDescription;
	}

	public String getJobSeekerExp() {
		return jobSeekerExp;
	}

	public void setJobSeekerExp(String jobSeekerExp) {
		this.jobSeekerExp = jobSeekerExp;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	@Override
	public String toString() {
		return "Resume [resumeId=" + resumeId + ", jobSeekerName=" + jobSeekerName + ", jobSeekerDescription="
				+ jobSeekerDescription + ", jobSeekerExp=" + jobSeekerExp + ", jobId=" + jobId + "]";
	}
	

	
}
