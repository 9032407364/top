package com.ust.employer.services;

import java.util.List;

import com.ust.employer.dto.Employer;
import com.ust.employer.dto.Jobs;
import com.ust.employer.exceptions.JobIdNotFoundException;

public interface JobsService {

	void createJob(Jobs jobs);

	void geByJobId(int jobId);

	void updateJob(Jobs jobs);

	void deketeAllJobs();

	void getByJobLocation(String jobLocation);

	void getByJobTitle(String jobTitle);

	void deleteJobById(int jobId);
	

	List<Jobs> getAllJobs();
	
	 
	 

}
