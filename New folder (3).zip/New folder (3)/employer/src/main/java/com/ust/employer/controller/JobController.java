package com.ust.employer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.employer.dto.Jobs;
import com.ust.employer.exceptions.JobIdNotFoundException;
import com.ust.employer.services.JobsService;
 

@RestController
@RequestMapping("/api/v1/")
public class JobController {
     
	@Autowired
	private JobsService jobService;
	
	private ResponseEntity responseEntity;
	

	@PostMapping("createJob")
	ResponseEntity<Jobs> addProfile(@RequestBody Jobs jobs)   
	{
		System.out.println(jobs);
		jobService.createJob(jobs);
		return new ResponseEntity(jobs,HttpStatus.CREATED);		
	}
	
 @GetMapping("getById/{jobId}")
    public ResponseEntity<Jobs> getProfileDetails(@PathVariable  int jobId)   {
	 try {
		 jobService.geByJobId(jobId);
        	responseEntity = new ResponseEntity(jobId , HttpStatus.OK);
        }
        catch (Exception e)
        {
            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }
 
 @GetMapping("getAllJobs")
	public ResponseEntity<List<Jobs>> getAllJobs() {
	 List<Jobs> profile = jobService.getAllJobs();
	return new ResponseEntity<List<Jobs>>(profile, HttpStatus.OK);

	}
 
 @RequestMapping(value = "updateJob", method = RequestMethod.PUT)
// @PutMapping("/api/v1/update")
	public ResponseEntity<Jobs> updateJob(@RequestBody Jobs jobs){
		
	 jobService.updateJob(jobs);
		ResponseEntity<Jobs> ep=new ResponseEntity<Jobs>(HttpStatus.CREATED);
		
		return ep;	
	}
 
 //@RequestMapping(value = "/delete/{resumeId}", method = RequestMethod.DELETE)
 @DeleteMapping("deleteByJobId/{jobId}")
	public ResponseEntity<Jobs> JobDelete(@PathVariable int jobId){
	 jobService.deleteJobById(jobId);
		return new ResponseEntity<Jobs>(HttpStatus.OK);
		 
	}
 
 @DeleteMapping("deleteAllJobs")
	public ResponseEntity<Jobs> deketeAllJobs(){
	 jobService.deketeAllJobs();
	return new ResponseEntity<Jobs>( HttpStatus.OK);

	}

  
 @GetMapping("getByJobLocation/{jobLocation}")
    public ResponseEntity<Jobs> getByJobLocation(@PathVariable  String jobLocation)   {
	 try {
		 jobService.getByJobLocation(jobLocation);
        	responseEntity = new ResponseEntity(jobLocation , HttpStatus.OK);
        }
        catch (Exception e)
        {
            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }
 @GetMapping("getByJobTitle/{jobTitle} ")
    public ResponseEntity<Jobs> getByJobTitle(@PathVariable  String jobTitle)   {
	 try {
		 jobService.getByJobTitle(jobTitle);
        	responseEntity = new ResponseEntity(jobTitle , HttpStatus.OK);
        }
        catch (Exception e)
        {
            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return responseEntity;
    }
	
}
