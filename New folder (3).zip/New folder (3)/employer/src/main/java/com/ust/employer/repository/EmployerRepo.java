package com.ust.employer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ust.employer.dto.Jobs;
 

@Repository
public interface EmployerRepo extends MongoRepository<Jobs, Integer>
            //JpaRepository<Jobs, Integer>
{

	void findByJobLocation(String jobLocation);

	void findByJobTitle(String jobTitle);	
	
}
