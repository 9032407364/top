package com.ust.employer.exceptions;

public class EmployerNotFoundException extends Exception{

}
