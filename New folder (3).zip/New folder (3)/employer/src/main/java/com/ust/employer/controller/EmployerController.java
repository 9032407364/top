package com.ust.employer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.employer.clients.EmployerClient;
import com.ust.employer.dto.Employer;
import com.ust.employer.dto.Jobs;
import com.ust.employer.exceptions.EmployerNotFoundException;
import com.ust.employer.exceptions.JobIdNotFoundException;
import com.ust.employer.services.EmployerRegService;
import com.ust.employer.services.JobsService;


@RestController
@RequestMapping("/api/v2/")
public class EmployerController {
	
	private ResponseEntity responseEntity;
	
	@Autowired
	private EmployerClient employeeClient;
	
	
	@Autowired
	JobsService empservice;
	@Autowired
	FeignProxy a;
	//private String b=null;
	@Autowired
	EmployerRegService erService;
	
	@GetMapping("/api/v1/hi")
	String a() {
	Optional<Bean> c=Optional.of(a.a());
		return c.get().getJwtToken();}
	 
	
	public EmployerController() {
		super();
	
	}
	
	
	@PostMapping("add")
	ResponseEntity<Employer> addEmployer(@RequestBody Employer employer) 
	{
		Employer emp =erService.addEmployer(employer);
		return new ResponseEntity(emp,HttpStatus.CREATED);		
	}
	
	@GetMapping("employer")
	ResponseEntity<List<Employer>> getAllEmployer()
	{	
		
		return ResponseEntity.ok(erService.getAllEmployer());	
		
	}
	 
	
	
	@GetMapping("getEmployer/{companyId}")
    public ResponseEntity<?> getEmployer(@PathVariable("companyId") int companyId) throws EmployerNotFoundException {

        try {
        	erService.getById(companyId);
            responseEntity = new ResponseEntity("Successfully got details !!!", HttpStatus.OK);
        } catch (EmployerNotFoundException e) {

            throw new EmployerNotFoundException();

                    }
        catch (Exception exception){
            String ex = exception.getMessage();
            System.out.println(exception.getMessage());
            responseEntity = new ResponseEntity("Error !!! Try after sometime.", HttpStatus.NOT_FOUND);
        }
        return responseEntity;
    }
	
	@DeleteMapping("deleteEmployer/{companyId}")
    public ResponseEntity<?> deleteEmployer(@PathVariable("companyId") int companyId) throws EmployerNotFoundException {

        try {
        	erService.deleteEmployerById(companyId);
            responseEntity = new ResponseEntity("Successfully deleted !!!", HttpStatus.OK);
        } catch (EmployerNotFoundException e) {

            throw new EmployerNotFoundException();

                    }
        catch (Exception exception){
            String ex = exception.getMessage();
            System.out.println(exception.getMessage());
            responseEntity = new ResponseEntity("Error !!! Try after sometime.", HttpStatus.NOT_FOUND);
        }
        return responseEntity;
    }
	
	 @RequestMapping(value = "Exist/{companyName}", method = RequestMethod.GET)
	   public ResponseEntity <Boolean> existt(@RequestParam  String companyName) throws EmployerNotFoundException{
		  boolean listem=erService.existMethod(companyName);
		   if(listem==false) {
			   throw new EmployerNotFoundException();
		   }
			return  new ResponseEntity <Boolean>(listem,HttpStatus.ACCEPTED);
	   }
	
	
	 @DeleteMapping("deleteAllEmployer")
		public ResponseEntity<Employer> deleteAllEmployer(){
		 erService.deleteAllEmployer();
		return new ResponseEntity<Employer>( HttpStatus.OK);

		}

	  
	 @GetMapping("getByCompanyName/{companyName}")
	    public ResponseEntity<Jobs> getByCompanyName(@PathVariable  String companyName)   {
		 try {
			 erService.getByCompanyName(companyName);
	        	responseEntity = new ResponseEntity(companyName , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 @GetMapping("getByRecruiterName/{recruiterName} ")
	    public ResponseEntity<Jobs> getByJobTitle(@PathVariable  String recruiterName)   {
		 try {
			 erService.getByRecruiterName(recruiterName);
	        	responseEntity = new ResponseEntity(recruiterName , HttpStatus.OK);
	        }
	        catch (Exception e)
	        {
	            responseEntity = new ResponseEntity<>("Error  !!! Enter Valid Details", HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        return responseEntity;
	    }
	 
	
}






