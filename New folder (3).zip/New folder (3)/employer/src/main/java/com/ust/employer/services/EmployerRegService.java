package com.ust.employer.services;

import java.util.List;

import com.ust.employer.dto.Employer;
import com.ust.employer.dto.Jobs;
import com.ust.employer.exceptions.EmployerNotFoundException;
import com.ust.employer.exceptions.JobIdNotFoundException;

public interface EmployerRegService {
	
	public Employer addEmployer(Employer emp);

	public List<Employer> getAllEmployer();

	public void deleteEmployerById(int companyId) throws EmployerNotFoundException;

	public boolean existMethod(String companyName) throws EmployerNotFoundException;

	public void getById(int companyId) throws EmployerNotFoundException;

	public void deleteAllEmployer();

	public void getByCompanyName(String companyName);

	public void getByRecruiterName(String recruiterName);

	

	 

}
