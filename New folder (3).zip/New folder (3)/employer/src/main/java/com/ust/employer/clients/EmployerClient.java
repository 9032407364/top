package com.ust.employer.clients;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient("book-library")
public interface EmployerClient {

	
	
	
}
