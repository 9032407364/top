package com.ust.employer.services.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.hibernate.id.SequenceGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ust.employer.dto.Employer;
import com.ust.employer.dto.Jobs;
import com.ust.employer.dto.Resume;
import com.ust.employer.exceptions.JobIdNotFoundException;
import com.ust.employer.repository.EmployerRepo;
 
import com.ust.employer.services.JobsService;

@Service
public class EmployerServiceImpl implements JobsService{
	
	 
	@Autowired
	private EmployerRepo empRepo;
	
	
	@Autowired
	RestTemplate restTemplate;


	@Override
	public void createJob(Jobs jobs) {
		Jobs job=(Jobs)jobs;
		int max = 250;
		  int min = 1;
		// create instance of Random class
		  Random randomNum = new Random();
		  int showMe = min + randomNum.nextInt(max);
		  job.setJobId(Integer.valueOf(showMe));
		job.setPublishedAt(LocalDateTime.now());
		empRepo.save(job);
		
	}


	@Override
	public void geByJobId(int jobId) {
		 empRepo.findById(jobId);
		
	}


	@Override
	public void updateJob(Jobs jobs) {
		empRepo.save(jobs);
		
	}


	@Override
	public void deketeAllJobs() {
		empRepo.deleteAll();
		
	}


	@Override
	public void getByJobLocation(String jobLocation) {
		empRepo.findByJobLocation(jobLocation);
		
	}


	@Override
	public void getByJobTitle(String jobTitle) {
		empRepo.findByJobTitle(jobTitle);
		
	}


	@Override
	public void deleteJobById(int jobId) {
		Integer a=Integer.valueOf(jobId);
		empRepo.deleteById(a);
		
	}


	@Override
	public List<Jobs> getAllJobs() {
		List<Jobs> jobs=empRepo.findAll();
		
		return jobs;
	}


	 
	 

	 
}
