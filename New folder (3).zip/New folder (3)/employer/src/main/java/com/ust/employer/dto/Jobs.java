package com.ust.employer.dto;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.mongodb.core.mapping.Document;

//@Entity
//@Table (name = "jobs")
@Document
public class Jobs {
	
	@Id
	private int JobId;
	
	private String jobTitle;
	
	private String category;
	
	private String companyName;
	private String jobLocation;
	
	private String status;
	
	private String action;
	
	 
	private String jobDescription;
	
	 
	private String jobExperience;
	
	private LocalDateTime publishedAt;

	public Jobs() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getJobId() {
		return JobId;
	}

	public void setJobId(int jobId) {
		JobId = jobId;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getJobLocation() {
		return jobLocation;
	}

	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getJobExperience() {
		return jobExperience;
	}

	public void setJobExperience(String jobExperience) {
		this.jobExperience = jobExperience;
	}

	public LocalDateTime getPublishedAt() {
		return publishedAt;
	}

	public void setPublishedAt(LocalDateTime publishedAt) {
		this.publishedAt = publishedAt;
	}

	@Override
	public String toString() {
		return "Jobs [JobId=" + JobId + ", jobTitle=" + jobTitle + ", category=" + category + ", companyName="
				+ companyName + ", jobLocation=" + jobLocation + ", status=" + status + ", action=" + action
				+ ", jobDescription=" + jobDescription + ", jobExperience=" + jobExperience + ", publishedAt="
				+ publishedAt + "]";
	}
	

}