package com.ust.employer.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.mongodb.core.mapping.Document;

//@Entity
//@Table (name = "employer")
@Document
public class Employer {
	
	@org.springframework.data.annotation.Id
	
	int companyId;
	
	 
	private String companyName;
	
	private String recruiterName;
	
	private String locaton;
	
	private long mobileNumber;
	
	private String emailId;
	
	private String mebmerShip;
	
	private String status;
	
	private String action;
	

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getRecruiterName() {
		return recruiterName;
	}

	public void setRecruiterName(String recruiterName) {
		this.recruiterName = recruiterName;
	}

	public String getLocaton() {
		return locaton;
	}

	public void setLocaton(String locaton) {
		this.locaton = locaton;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMebmerShip() {
		return mebmerShip;
	}

	public void setMebmerShip(String mebmerShip) {
		this.mebmerShip = mebmerShip;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "EmployerEntity [companyId=" + companyId + ", companyName=" + companyName + ", recruiterName=" + recruiterName
				+ ", locaton=" + locaton + ", mobileNumber=" + mobileNumber + ", emailId=" + emailId + ", mebmerShip="
				+ mebmerShip + ", status=" + status + ", action=" + action + "]";
	}

	 
	
	
}
