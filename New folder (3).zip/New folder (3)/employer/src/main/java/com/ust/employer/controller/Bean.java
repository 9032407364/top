package com.ust.employer.controller;

public class Bean {
private String role="hi";
private String JwtToken;
public String getJwtToken() {
	return JwtToken;
}
public void setJwtToken(String jwtToken) {
	JwtToken = jwtToken;
}
public Bean(String role, String jwtToken) {
	super();
	this.role = role;
	JwtToken = jwtToken;
}
public Bean() {
	super();
	// TODO Auto-generated constructor stub
}
}
